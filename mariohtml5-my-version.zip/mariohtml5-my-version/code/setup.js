/**
	Just create the global mario object.
	Code by Rob Kleffner, 2011
*/

window.Mario = window.Mario || {
    Score: 0
};
var Mario = window.Mario;
